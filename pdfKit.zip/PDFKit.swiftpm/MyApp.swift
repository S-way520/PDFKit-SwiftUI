import SwiftUI
@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
struct ContentView: View {
    @State var Show = false
    var body: some View {
        MPDF(Show: Show, PDFname: "RealityKit", PDFnameD: "RealityKit")
    }
}
